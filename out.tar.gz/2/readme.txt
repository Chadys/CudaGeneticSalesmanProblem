generations : 20
cities : 50
islands : 2
