generations : 100
cities : 50
islands : 10
